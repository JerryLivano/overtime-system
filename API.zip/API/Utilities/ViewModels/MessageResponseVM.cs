﻿namespace API.Utilities.ViewModels
{
    public record MessageResponseVM(
        int Code,
        string Status,
        string Message);
}
