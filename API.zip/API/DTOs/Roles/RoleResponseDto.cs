﻿namespace API.DTOs.Roles
{
    public record RoleResponseDto(
        Guid Id,
        string Name);
}
