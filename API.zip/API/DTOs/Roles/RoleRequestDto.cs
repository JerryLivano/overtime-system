﻿namespace API.DTOs.Roles
{
    public record RoleRequestDto(
        string Name);
}
